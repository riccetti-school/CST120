Dominic Riccetti
CST120
Git repository: https://github.com/riccetti-school/CST120.git
LOOM VIDEO LINK: https://www.loom.com/share/00aafca5768c43e2aa994cc88cf0a5e6?sharedAppSource=personal_library
